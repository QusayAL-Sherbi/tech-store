  <div class="th-dashboard">
      <div class="content free-pro">
            <table class="table">
               <tbody class="table-body">
                  <tr class="table-head">
                     <th class="title" align="left"><?php _e('Features','big-store'); ?></th>
                     <th class="status" align="center"><?php _e('Big Store','big-store'); ?> </th>
                     <th class="status" align="center"><?php _e('Big Store Pro','big-store'); ?> </th>
                  </tr>

                  <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4><?php _e('Section Hide Option','big-store'); ?> </h4>
                        </div>
                     </td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span></td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span></td>
                  </tr>

                  
                  
                  <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4><?php _e('Header Layout','big-store'); ?> </h4>
                        </div>
                     </td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span><span class="info"><?php _e('(One layout)','big-store'); ?> </span></td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span><span class="info"><?php _e('(Four Layout)','big-store'); ?> </span></td>
                  </tr>



                  <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4><?php _e('Footer Layout','big-store'); ?> </h4>
                        </div>
                     </td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span>

                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span>

                  </tr>


                  <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4><?php _e('Full Color & Background Control','big-store'); ?> </h4>
                        </div>
                     </td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span><span class="info"><?php _e('(Basic)','big-store'); ?> </span></td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span><span class="info"><?php _e('(Advanced)','big-store'); ?> </span></td>
                  </tr>



                  <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4><?php _e('Tabbed Product Carousel Section','big-store'); ?> </h4>
                        </div>
                     </td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span>

                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span>

                  </tr>


                  <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4><?php _e('Woo Category Section','big-store'); ?> </h4>
                        </div>
                     </td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span>
                        <span class="info"><?php _e('(One Layouts)','big-store'); ?> </span></td>

                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span>
                        <span class="info"><?php _e('(Three Layouts)','big-store'); ?> </span></td>

                  </tr>


                   <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4><?php _e('Product List Carousel Section','big-store'); ?> </h4>
                        </div>
                     </td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span>
                        </td>

                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span>
                     </td>

                  </tr>



                  <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4><?php _e('Support','big-store'); ?> </h4>
                        </div>
                     </td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span>
                        <span class="info"><?php _e('(Basic)','big-store'); ?> </span></td>

                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span>
                     <span class="info"><?php _e('(Priority)','big-store'); ?> </span></td>

                  </tr>








                  <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4> <?php _e('Section Ordering','big-store'); ?> </h4>
                        </div>
                     </td>
                     <td class="status error"><span class="dashicon dashicons dashicons-no-alt" size="30"></span></td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span></td>
                  </tr>


                  <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4> <?php _e('Four Custom Section','big-store'); ?> </h4>
                        </div>
                     </td>
                     <td class="status error"><span class="dashicon dashicons dashicons-no-alt" size="30"></span></td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span></td>
                  </tr>


                  <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4> <?php _e('Off Canvas Sidebar','big-store'); ?> </h4>
                        </div>
                     </td>
                     <td class="status error"><span class="dashicon dashicons dashicons-no-alt" size="30"></span></td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span></td>
                  </tr>


                  <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4> <?php _e('Big Featured Product Section','big-store'); ?> </h4>
                        </div>
                     </td>
                     <td class="status error"><span class="dashicon dashicons dashicons-no-alt" size="30"></span></td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span></td>
                  </tr>


                  <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4> <?php _e('Brand Section','big-store'); ?> </h4>
                        </div>
                     </td>
                     <td class="status error"><span class="dashicon dashicons dashicons-no-alt" size="30"></span></td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span></td>
                  </tr>


                  <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4> <?php _e('Tabbed Product list Carousel Section','big-store'); ?> </h4>
                        </div>
                     </td>
                     <td class="status error"><span class="dashicon dashicons dashicons-no-alt" size="30"></span></td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span></td>
                  </tr>


                   <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4> <?php _e('Product Multi Slide Widget','big-store'); ?> </h4>
                        </div>
                     </td>
                     <td class="status error"><span class="dashicon dashicons dashicons-no-alt" size="30"></span></td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span></td>
                  </tr>


                  <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4> <?php _e('Product Vertical tabbed Widget','big-store'); ?> </h4>
                        </div>
                     </td>
                     <td class="status error"><span class="dashicon dashicons dashicons-no-alt" size="30"></span></td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span></td>
                  </tr>



                  <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4> <?php _e('About us Widget ','big-store'); ?> </h4>
                        </div>
                     </td>
                     <td class="status error"><span class="dashicon dashicons dashicons-no-alt" size="30"></span></td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span></td>
                  </tr>


                   <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4> <?php _e('Testimonial Widget ','big-store'); ?> </h4>
                        </div>
                     </td>
                     <td class="status error"><span class="dashicon dashicons dashicons-no-alt" size="30"></span></td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span></td>
                  </tr>                

                  
                    <tr class="feature-row th-buy-pro">
                     <td class="title">
                        <div class="title-wrap">
                           <h4><?php _e('Get Pro Theme','big-store'); ?> </h4>
                        </div>
                     </td>
                     <td class="status upsell"><?php _e('Get access to all Pro features','big-store'); ?> </td>
                     <td class="status success"><a href="https://themehunk.com/product/big-store-pro/" target="_blank" rel="external noreferrer noopener" class="components-button is-primary"><?php _e('Get Big Store Pro Now','big-store'); ?></a></td>
                  </tr>



               </tbody>
            </table>
      </div>
   </div>
