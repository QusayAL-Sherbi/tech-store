<?php
define('BIG_STORE_TOP_HEADER_LAYOUT_1', BIG_STORE_THEME_URI. "customizer/images/top-header-1.png");
define('BIG_STORE_TOP_HEADER_LAYOUT_2', BIG_STORE_THEME_URI. "customizer/images/top-header-2.png");
define('BIG_STORE_TOP_HEADER_LAYOUT_3', BIG_STORE_THEME_URI. "customizer/images/top-header-3.png");
define('BIG_STORE_TOP_HEADER_LAYOUT_NONE', BIG_STORE_THEME_URI. "customizer/images/top-header-none.png");

define('BIG_STORE_MAIN_HEADER_LAYOUT_ONE', BIG_STORE_THEME_URI. "customizer/images/header-layout-1.png");
define('BIG_STORE_MAIN_HEADER_LAYOUT_TWO', BIG_STORE_THEME_URI. "customizer/images/header-layout-2.png");
define('BIG_STORE_MAIN_HEADER_LAYOUT_THREE', BIG_STORE_THEME_URI. "customizer/images/header-layout-3.png");
define('BIG_STORE_MAIN_HEADER_LAYOUT_FOUR', BIG_STORE_THEME_URI. "customizer/images/header-layout-4.png");


define('BIG_STORE_TOP_FOOTER_LAYOUT_2', BIG_STORE_THEME_URI. "customizer/images/top-footer-2.png");
define('BIG_STORE_TOP_FOOTER_LAYOUT_3', BIG_STORE_THEME_URI. "customizer/images/top-footer-3.png");

define('BIG_STORE_FOOTER_WIDGET_LAYOUT_1', BIG_STORE_THEME_URI. "customizer/images/widget-footer-1.png");
define('BIG_STORE_FOOTER_WIDGET_LAYOUT_2', BIG_STORE_THEME_URI. "customizer/images/widget-footer-2.png");
define('BIG_STORE_FOOTER_WIDGET_LAYOUT_3', BIG_STORE_THEME_URI. "customizer/images/widget-footer-3.png");
define('BIG_STORE_FOOTER_WIDGET_LAYOUT_4', BIG_STORE_THEME_URI. "customizer/images/widget-footer-4.png");
define('BIG_STORE_FOOTER_WIDGET_LAYOUT_5', BIG_STORE_THEME_URI. "customizer/images/widget-footer-5.png");
define('BIG_STORE_FOOTER_WIDGET_LAYOUT_6', BIG_STORE_THEME_URI. "customizer/images/widget-footer-6.png");
define('BIG_STORE_FOOTER_WIDGET_LAYOUT_7', BIG_STORE_THEME_URI. "customizer/images/widget-footer-7.png");
define('BIG_STORE_FOOTER_WIDGET_LAYOUT_8', BIG_STORE_THEME_URI. "customizer/images/widget-footer-8.png");
define('BIG_STORE_FOOTER_WIDGET_LAYOUT_NONE', BIG_STORE_THEME_URI. "customizer/images/widget-footer-none.png");
//SLIDER
define('BIG_STORE_SLIDER_LAYOUT_1', BIG_STORE_THEME_URI. "customizer/images/slider-layout-1.png");
define('BIG_STORE_SLIDER_LAYOUT_2', BIG_STORE_THEME_URI. "customizer/images/slider-layout-2.png");
define('BIG_STORE_SLIDER_LAYOUT_3', BIG_STORE_THEME_URI. "customizer/images/slider-layout-3.png");
define('BIG_STORE_SLIDER_LAYOUT_4', BIG_STORE_THEME_URI. "customizer/images/slider-layout-4.png");
define('BIG_STORE_SLIDER_LAYOUT_5', BIG_STORE_THEME_URI. "customizer/images/slider-layout-5.png");
//category slider
define('BIG_STORE_CAT_SLIDER_LAYOUT_1', BIG_STORE_THEME_URI. "customizer/images/category-slider-1.png");
define('BIG_STORE_CAT_SLIDER_LAYOUT_2', BIG_STORE_THEME_URI. "customizer/images/category-slider-2.png");
define('BIG_STORE_CAT_SLIDER_LAYOUT_3', BIG_STORE_THEME_URI. "customizer/images/category-slider-3.png");
//Banner Slider
define('BIG_STORE_BANNER_IMG_LAYOUT_1', BIG_STORE_THEME_URI. "customizer/images/banner-image-1.png");
define('BIG_STORE_BANNER_IMG_LAYOUT_2', BIG_STORE_THEME_URI. "customizer/images/banner-image-2.png");
define('BIG_STORE_BANNER_IMG_LAYOUT_3', BIG_STORE_THEME_URI. "customizer/images/banner-image-3.png");
define('BIG_STORE_BANNER_IMG_LAYOUT_4', BIG_STORE_THEME_URI. "customizer/images/banner-image-4.png");
define('BIG_STORE_BANNER_IMG_LAYOUT_5', BIG_STORE_THEME_URI. "customizer/images/banner-image-5.png");
//Custom section
define('BIG_STORE_CUSTOM_LAYOUT_1', BIG_STORE_THEME_URI. "customizer/images/widget-footer-1.png");
define('BIG_STORE_CUSTOM_LAYOUT_2', BIG_STORE_THEME_URI. "customizer/images/widget-footer-2.png");
define('BIG_STORE_CUSTOM_LAYOUT_3', BIG_STORE_THEME_URI. "customizer/images/widget-footer-3.png");


define('BIG_STORE_ABOUT_IMG_1', BIG_STORE_THEME_URI. "image/founder.png");
